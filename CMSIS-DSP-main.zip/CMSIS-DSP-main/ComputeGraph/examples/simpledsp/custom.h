#ifndef _CUSTOM_H_

typedef float float32_t;

#define OFFSET_VALUE 2.0f

#endif 