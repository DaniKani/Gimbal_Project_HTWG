# Example 9

Thsi example is just checking that duplicate node insertion and delay on a connection are working well together.

The Python script is able to schedule the graph.

![graph9](docassets/graph9.png)