#ifndef _CUSTOM_H_

#include "cg_status.h"

#define CG_BEFORE_BUFFER __ALIGNED(4)

#define CG_AFTER_ITERATION count++

#endif 