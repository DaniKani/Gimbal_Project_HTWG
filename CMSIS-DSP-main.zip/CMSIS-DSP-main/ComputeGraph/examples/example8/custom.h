#ifndef _CUSTOM_H_


#ifdef   __cplusplus
extern "C"
{
#endif

typedef struct {
    float re;
    float im;
} complex;


#ifdef   __cplusplus
}
#endif


#endif 