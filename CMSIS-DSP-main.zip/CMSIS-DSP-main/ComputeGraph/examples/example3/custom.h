#ifndef _CUSTOM_H_

#define HALF 0.5
extern const float32_t HANN[256];



#endif 