#ifndef _CUSTOM_H_

typedef float float32_t;

#if defined(RTE_Compiler_EventRecorder)
#include "EventRecorder.h"
#endif 

#endif 