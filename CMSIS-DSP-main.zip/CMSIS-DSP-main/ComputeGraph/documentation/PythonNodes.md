# Python Nodes and classes

Python implementation of the nodes to be run from a Python scheduler.

You don't need this if you're only working with C++ schedulers.

(DOCUMENTATION TO BE WRITTEN)

## Mandatory classes

FIFO

GenericNode

GenericNode12

GenericNode13

GenericNode21

GenericSource

GenericSink

OverlapAdd

SlidingBuffer

## Optional nodes

CFFT

CIFFT

InterleavedStereoToMono

MFCC

NullSink

ToComplex

ToReal

Unzip

Zip

Duplicate

Duplicate2

Duplicate3

### Host

FileSink

FileSource

WavSource

WavSink 

NumpySink

VHTSource

VHTSink